// View 1
const view1 = document.querySelector(".one__view");
const view1OpenBtn = document.querySelector(".one__view__openBtn");
const view1CloseBtn = document.querySelector(".one__view__closeBtn");
const view1Overlay = document.querySelector(".one__view-overlay");

view1OpenBtn.addEventListener("click", function () {
  view1.classList.add("one__showview");
  view1Overlay.classList.add("one__transparentBcg");
  html.classList.add("no-scroll");
});

view1CloseBtn.addEventListener("click", function () {
  view1.classList.remove("one__showview");
  view1Overlay.classList.remove("one__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 2
const view2 = document.querySelector(".two__view");
const view2OpenBtn = document.querySelector(".two__view__openBtn");
const view2CloseBtn = document.querySelector(".two__view__closeBtn");
const view2Overlay = document.querySelector(".two__view-overlay");

view2OpenBtn.addEventListener("click", function () {
  view2.classList.add("two__showview");
  view2Overlay.classList.add("two__transparentBcg");
  html.classList.add("no-scroll");
});

view2CloseBtn.addEventListener("click", function () {
  view2.classList.remove("two__showview");
  view2Overlay.classList.remove("two__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 3
const view3 = document.querySelector(".three__view");
const view3OpenBtn = document.querySelector(".three__view__openBtn");
const view3CloseBtn = document.querySelector(".three__view__closeBtn");
const view3Overlay = document.querySelector(".three__view-overlay");

view3OpenBtn.addEventListener("click", function () {
  view3.classList.add("three__showview");
  view3Overlay.classList.add("three__transparentBcg");
  html.classList.add("no-scroll");
});

view3CloseBtn.addEventListener("click", function () {
  view3.classList.remove("three__showview");
  view3Overlay.classList.remove("three__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 4
const view4 = document.querySelector(".four__view");
const view4OpenBtn = document.querySelector(".four__view__openBtn");
const view4CloseBtn = document.querySelector(".four__view__closeBtn");
const view4Overlay = document.querySelector(".four__view-overlay");

view4OpenBtn.addEventListener("click", function () {
  view4.classList.add("four__showview");
  view4Overlay.classList.add("four__transparentBcg");
  html.classList.add("no-scroll");
});

view4CloseBtn.addEventListener("click", function () {
  view4.classList.remove("four__showview");
  view4Overlay.classList.remove("four__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 5
const view5 = document.querySelector(".five__view");
const view5OpenBtn = document.querySelector(".five__view__openBtn");
const view5CloseBtn = document.querySelector(".five__view__closeBtn");
const view5Overlay = document.querySelector(".five__view-overlay");

view5OpenBtn.addEventListener("click", function () {
  view5.classList.add("five__showview");
  view5Overlay.classList.add("five__transparentBcg");
  html.classList.add("no-scroll");
});

view5CloseBtn.addEventListener("click", function () {
  view5.classList.remove("five__showview");
  view5Overlay.classList.remove("five__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 6
const view6 = document.querySelector(".six__view");
const view6OpenBtn = document.querySelector(".six__view__openBtn");
const view6CloseBtn = document.querySelector(".six__view__closeBtn");
const view6Overlay = document.querySelector(".six__view-overlay");

view6OpenBtn.addEventListener("click", function () {
  view6.classList.add("six__showview");
  view6Overlay.classList.add("six__transparentBcg");
  html.classList.add("no-scroll");
});

view6CloseBtn.addEventListener("click", function () {
  view6.classList.remove("six__showview");
  view6Overlay.classList.remove("six__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 7
const view7 = document.querySelector(".seven__view");
const view7OpenBtn = document.querySelector(".seven__view__openBtn");
const view7CloseBtn = document.querySelector(".seven__view__closeBtn");
const view7Overlay = document.querySelector(".seven__view-overlay");

view7OpenBtn.addEventListener("click", function () {
  view7.classList.add("seven__showview");
  view7Overlay.classList.add("seven__transparentBcg");
  html.classList.add("no-scroll");
});

view7CloseBtn.addEventListener("click", function () {
  view7.classList.remove("seven__showview");
  view7Overlay.classList.remove("seven__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 8
const view8 = document.querySelector(".eight__view");
const view8OpenBtn = document.querySelector(".eight__view__openBtn");
const view8CloseBtn = document.querySelector(".eight__view__closeBtn");
const view8Overlay = document.querySelector(".eight__view-overlay");

view8OpenBtn.addEventListener("click", function () {
  view8.classList.add("eight__showview");
  view8Overlay.classList.add("eight__transparentBcg");
  html.classList.add("no-scroll");
});

view8CloseBtn.addEventListener("click", function () {
  view8.classList.remove("eight__showview");
  view8Overlay.classList.remove("eight__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 9
const view9 = document.querySelector(".nine__view");
const view9OpenBtn = document.querySelector(".nine__view__openBtn");
const view9CloseBtn = document.querySelector(".nine__view__closeBtn");
const view9Overlay = document.querySelector(".nine__view-overlay");

view9OpenBtn.addEventListener("click", function () {
  view9.classList.add("nine__showview");
  view9Overlay.classList.add("nine__transparentBcg");
  html.classList.add("no-scroll");
});

view9CloseBtn.addEventListener("click", function () {
  view9.classList.remove("nine__showview");
  view9Overlay.classList.remove("nine__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 10
const view10 = document.querySelector(".ten__view");
const view10OpenBtn = document.querySelector(".ten__view__openBtn");
const view10CloseBtn = document.querySelector(".ten__view__closeBtn");
const view10Overlay = document.querySelector(".ten__view-overlay");

view10OpenBtn.addEventListener("click", function () {
  view10.classList.add("ten__showview");
  view10Overlay.classList.add("ten__transparentBcg");
  html.classList.add("no-scroll");
});

view10CloseBtn.addEventListener("click", function () {
  view10.classList.remove("ten__showview");
  view10Overlay.classList.remove("ten__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 11
const view11 = document.querySelector(".eleven__view");
const view11OpenBtn = document.querySelector(".eleven__view__openBtn");
const view11CloseBtn = document.querySelector(".eleven__view__closeBtn");
const view11Overlay = document.querySelector(".eleven__view-overlay");

view11OpenBtn.addEventListener("click", function () {
  view11.classList.add("eleven__showview");
  view11Overlay.classList.add("eleven__transparentBcg");
  html.classList.add("no-scroll");
});

view11CloseBtn.addEventListener("click", function () {
  view11.classList.remove("eleven__showview");
  view11Overlay.classList.remove("eleven__transparentBcg");
  html.classList.remove("no-scroll");
});

// View 12
const view12 = document.querySelector(".twelve__view");
const view12OpenBtn = document.querySelector(".twelve__view__openBtn");
const view12CloseBtn = document.querySelector(".twelve__view__closeBtn");
const view12Overlay = document.querySelector(".twelve__view-overlay");

view12OpenBtn.addEventListener("click", function () {
  view12.classList.add("twelve__showview");
  view12Overlay.classList.add("twelve__transparentBcg");
  html.classList.add("no-scroll");
});

view12CloseBtn.addEventListener("click", function () {
  view12.classList.remove("twelve__showview");
  view12Overlay.classList.remove("twelve__transparentBcg");
  html.classList.remove("no-scroll");
});
