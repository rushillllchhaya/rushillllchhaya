import requests

# insert your real key here!
access_key = "682c771e-5097-43e7-abeb-a67373a980a4"

headers = {
    "X-Meteum-API-Key": access_key
}

query = "{weatherByPoint(request: { lat: 52.37125, lon: 4.89388 }) {forecast {days(limit: 7) {time sunriseTime sunsetTime parts {day {avgTemperature} night {avgTemperature}}}}}}"

response = requests.post('https://api.meteum.ai/graphql/query', headers=headers, json={'query': query})

forecast = response.json()

tempday1 = forecast['data']['weatherByPoint']['forecast']['days'][1]['parts']['day']['avgTemperature']
tempnight1 = forecast['data']['weatherByPoint']['forecast']['days'][1]['parts']['night']['avgTemperature']

# day1temp.config(text=f"Day:{tempday1}\n Night:{tempnight1}")

print(tempday1)
print(tempnight1)