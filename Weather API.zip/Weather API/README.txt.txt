# Weather GUI Application

This is a Python GUI project for retrieving and displaying weather information for a given location. The application utilizes the OpenWeatherMap API to fetch current weather data, such as temperature, humidity, wind speed, and weather description, for the specified location.

## Getting Started

To use this application, you need to have Python 3 installed on your system. You can download Python from the official website: https://www.python.org/downloads/.

Additionally, you need to install the following Python packages:

- tkinter
- requests

You can install these packages using pip by running the following command:

```
pip install tkinter requests
```

Once you have installed the necessary packages, you can run the application by executing the `weather.py` file. 

## Usage

Upon running the application, you will be presented with a simple GUI interface that allows you to enter a location and retrieve its current weather information. 

To retrieve weather information, follow these steps:

1. Enter a location (e.g. city, state, or zip code) in the input field.
2. Click the "Get Weather" button to fetch weather data from the OpenWeatherMap API.
3. The weather information will be displayed in the GUI interface, including temperature, humidity, wind speed, and weather description.

## Limitations

This application has some limitations due to the nature of the OpenWeatherMap API:

- The API limits the number of requests you can make per day based on your plan.
- The API may not have weather information for all locations, especially smaller or less populated areas.
- The API may not provide accurate weather information for some locations.



THIS PROJECT IS DONE BY:-

RUSHIL CHHAYA 21BCE040
MANAN DUDHAIYA 21BCE065